package com.api.testcase;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.List;

public class ApiTests {
    public Response response;
    String apiUrl = "https://reqres.in/api/users?page=2";

    @BeforeClass
    public void beforeClassMethod() {
        response = RestAssured.given().get(apiUrl);
    }

    @Test
    public void validateTotalPagesEquals2() {
        int actualValue = response.jsonPath().get("page");
        Assert.assertEquals(actualValue, 2);
    }

    @Test
    public void validateStatusCode200() {
        Assert.assertEquals(response.getStatusCode(), 200);
    }

    @Test
    public void validateEmailCode() {
        List<String> datalist = response.jsonPath().getList("data.email");
        Assert.assertEquals(datalist.contains("byron.fields@reqres.in"), true);
    }

}
